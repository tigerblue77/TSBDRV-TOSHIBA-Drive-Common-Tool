#!/usr/bin/python
# -------------------------------------------------------------------------------
# Name:        self_test
#
# Purpose:     start the self test and change for time completion
#
# Created:     09/06/2016
#
# Copyright:   Copyright (C) 2017-18 Toshiba Electronic Devices & Storage Corporation. All Rights Reserved.
#
#
# -------------------------------------------------------------------------------

# Import python modules
import sys
import re
import subprocess
import threading
import os
import signal
import time
import argparse
from datetime import datetime
import pdb

helpStr = """"

Run short self Test
"""

#check whether tsbdrv present on the system
def cmd_exists(cmd):
    return any(
        os.access(os.path.join(path, cmd), os.X_OK)
        for path in os.environ["PATH"].split(os.pathsep)
    )

if os.name == "nt":
    if cmd_exists("tsbdrv.exe"):
       tsbdrvPath = "tsbdrv"
    else:
        #In windows check if parent directory contains the tsbdrv.exe
        path1 = os.getcwd()
        parentPath = os.path.abspath(os.path.join(path1, os.pardir))
        for root, dirs, files in os.walk(parentPath):
            for tsbdrvEXE in files:
                if re.search(r'tsbdrv.exe',tsbdrvEXE):
                    tsbdrvPath = os.path.join(root,tsbdrvEXE)
                    break
    #If in windows tsbdrv not found in the parent directory then we will exit
    try :
        tsbdrvPath
        print "tsbdrv is installed on the system"
    except NameError:
        print '''We are unable to find the tsbdrv on the system. Please add tsbdrv to the Environmental variables
                 or run the script from the TSBDRV_SCRIPT folder'''
        sys.exit(1)

else:
    #If system is linux we will exit script as tsbdrv is not found
    if cmd_exists("tsbdrv"):
       tsbdrvPath = "tsbdrv"
    else:
        print "tsbdrv is not installed.Exiting the Script...."
        sys.exit(1)


def readcmdarg():
    """This function is used to define the argument passed from the commmand line
    """
    global SelfTError
    SelfTError=[]
    parser = argparse.ArgumentParser()
    parser.add_argument('-dev', action='store', dest='device_name', required=True,
                    help='device name : compulsory parameter needs to be passed. (e.g sda).User can pass "all" option for executing script on available devices')
    parser.add_argument('-dev_type', action='store', dest='device_type',default = 'all',
                    help='device type : User can pass the device type (e.g. ATA,SCSI,NVME).User can pass "all"'
                                      ' to pick all type of devices.[Default : all]')
    parser.add_argument('-test_type', action='store', dest='test_type',default = 'short',
                                help='test type : User can pass the self test type as short or long. [Default : short].')

    parser.add_argument('-t', action='store', dest='timeout',default = None , type=int,
                    help='timeout value waiting for completion of selftest in min. [short test Default : 4 Min, long test Default : 60 Min]')
    parser.add_argument('-p', action='store', dest='polling_time',default = None, type=int,
                    help='time in seconds waiting for the next polling. [short test Default : 10 Sec, long test Default : 60 Sec]')
    parser.add_argument('-s', action='store_true', dest='slient' ,
                    help='silent option')
    parser.add_argument('-v', action='store_true', dest='verbose',
                help='verbose option')

    results = parser.parse_args()
    return results

def printMsg(msg,printmsg=1):
    """This function is used to print a message
       take a input as a printing message
    """
    if cmdargs.slient:
        loginfo (msg,0)
    else:
        loginfo (msg,printmsg)

def printErr(errmsg):
    """This message prints error and exit the script
	   take a error message as a input
    """
    logerror ("fail judgement: " + errmsg)
    raise Exception(errmsg)
    
def _kill_pid_after_timeout(pid):
    """Function to kill the process after set time-out
       Input : process id pid Return : None
    """
    os.kill(pid, signal.SIGTERM)
    # Kill the process with SIGTERM and inform to calling function
    kil_chk.set()
    return

def runCmd(cmd_to_exe):
    """Function to execute command
      Input : command to be executed
      Return : Dictionary of command output, error if any, status
               of execution, time-out error if occurred
    """

    if cmdargs.verbose:
        printMsg ("Command to be executed - " + cmd_to_exe,1)
    else:
        printMsg ("Command to be executed - " + cmd_to_exe,0)

    # Timeout set is to Maximum as 10 Hrs. for execution of above command
    timeout = 36000
    # Execute command using subprocess module
    run_cmd = subprocess.Popen(cmd_to_exe, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, shell=True)
    # Get the pid of process
    pid = run_cmd.pid
    # start watchdog,if command taking longer time than timeout kill process
    watchdog = threading.Timer(timeout, _kill_pid_after_timeout, args=(pid, ))
    watchdog.start()
    # Get the command output and error in any from process
    (cmd_output, cmd_err) = run_cmd.communicate()
    status = run_cmd.wait()
    watchdog.cancel()
    timeout_err = kil_chk.isSet()
    kil_chk.clear()
    res = {"OUTPUT": cmd_output, "ERROR": cmd_err, "STATUS": status,
           "TIMEOUTERR": timeout_err}
    return res

def checkForSuccess(res1):
    '''Function to check the failure status of command
       If command is failed then script will exit without further execution
    '''
    if (res1["STATUS"] == 0):
       if cmdargs.verbose:
           printMsg ("Output :\n" + res1["OUTPUT"],1)
       else:
            printMsg ("Output :\n" + res1["OUTPUT"],0)

    else:
        # Check for error or timeout in case of error
        if (res1["ERROR"]):
             printErr ("TSBDRV Error, " + res1["ERROR"])
        elif (res1["TIMEOUTERR"]):
             printErr ("Command Time-out error occurred")
    # if failed, script should exit without further execution

def parseOutput(output):
    '''Function is used to parse the tsbdrv command output
       returns the dictionary formed as per the command output
    '''
    dict = {}
    outarray1 = output.rstrip().split(';')
    if 'See log file' in outarray1[-1]:
        outarray1.pop()
    for out in outarray1:
        if out:
            outarray2 = out.split('=')
            dict[outarray2[0]] = outarray2[1]
    return dict

def pollforCompletion():
    """ Function to poll the status of the self test
        After completion of self test it will return to main program
    """
    global SelfTError

    var = 1
    SelfTError=[]
    #Infinite loop for polling the status
    while var == 1:
        cmd_to_exe2 = "\"%s\" selftest status %s -t" %(tsbdrvPath,DeviceId)

        res2 = runCmd(cmd_to_exe2)
        checkForSuccess(res2)

        dict1 = parseOutput(res2["OUTPUT"])
        #check self test completed or not
        for parseKey, parseValue in dict1.items():
            matchObj = re.match( r'.*__selftest__active',parseKey, re.I)
            if ( matchObj and parseValue =="false"):
                printMsg("self test completed successfully")
                return
        checktimeout = toc(1,"TRUE")
        minute1 = (str(checktimeout).split(':'))[1]
        if (int (minute1) >= int(selftesttimeout)):
             printErr("##1## Self Test Timeout")
        time.sleep(int (polltime))
        printMsg("waiting for self test completion")

TIC_TIME = {}
TOC_TIME = {}
def tic(tag=None):
    '''Start timer function.
    tag = used to link a tic to a later toc. Can be any dictionary-able key.
    '''
    global TIC_TIME
    if tag is None:
        tag = 'default'

    try:
        TIC_TIME[tag] = datetime.now()
    except NameError:
        TIC_TIME = {tag: datetime.now()}

def toc(tag=None, save=False, fmt=False):
    '''Timer ending function.
    tag - used to link a toc to a previous tic. Allows multiple timers, nesting timers.
    save - if True, returns float time to out (in seconds)
    fmt - if True, formats time in H:M:S, if False just seconds.
    '''
    global TOC_TIME
    template = ''
    if tag is None:
        tag = 'default'
    else:
        template = '%s - '%tag + template
    try:
        TOC_TIME[tag] = datetime.now()
    except NameError:
        TOC_TIME = {tag: datetime.now()}
    if TIC_TIME:
        d = (TOC_TIME[tag]-TIC_TIME[tag])

    if save:
        runtime = (str(d).split(':'))[2]
        return d
    else:
        var = 0

def _log(tag, msg,printmsg=1):
    today = []
    today = time.localtime()[0:6]
    timestr = "%02d/%02d/%04d %02d:%02d:%02d [%s] " % (today[2], today[1], today[0], today[3], today[4], today[5], tag)
    blank = ' ' * len(timestr);

    if (type(msg).__name__ == "list"):
        for line in msg:
            if printmsg:
                print("%s %s" % (blank, line))
            if (logHdl):
                logHdl.write("%s %s\n" % (blank, line))
    else:
        if printmsg:
            print timestr, msg
        if (logHdl):
            logHdl.write(timestr + msg + "\n")
            logHdl.flush()

def loginfo(msg,printmsg=1):
    """
    Print message on console and log it to the logfile

    Input:
        msg - Message string or an array containing strings
        printmsg - If 1 the print the message on the console

    Return: None

    Example:  logMsg(["hello", "world"],1)

    """
    _log("INFO", msg,printmsg)

def logerror(msg):
    """
    Print error message on console and log it to the logfile

    Input:
        msg - Message string or an array containing strings

    Return: None

    Example:  logError("Error occured")

    """
    _log("ERROR", msg)

def getAllDevices():
    """
    Get the List of all the devices present on host

    Input: None

    Return: List of all the devices
    """
    returnDevice = []
    cmd_query = "tsbdrv query all -t"
    Queryres = runCmd(cmd_query)
    checkForSuccess(Queryres)
    Queryout = Queryres["OUTPUT"]
    QueryoutLines = Queryout.rstrip().split("\n")
    for line in QueryoutLines:
        devices = line.rstrip().split(";")[0]
        device = devices.rstrip().split("=")
        returnDevice.append(device[1])
    return returnDevice

def getDeviceType(deviceId):
    """
    Retrun the Device type for the particular device
    Input: Device e.g /dev/sda
    Retrun : String of device type e.g ATA,SCSI
    """
    deviceType=""
    cmd_query = "tsbdrv query %s -t" % (deviceId)
    Queryres = runCmd(cmd_query)
    checkForSuccess(Queryres)
    Queryout = Queryres["OUTPUT"]
    QueryoutLines = Queryout.rstrip().split("\n")
    for line in QueryoutLines:
        deviceOut = line.rstrip().split(";")
        for devLine in deviceOut:
            deviceOutput = devLine.rstrip().split("=")
            if re.match(r'.*dev_type$',deviceOutput[0]):
                return deviceOutput[1]

def execute_main(DeviceId):
    #take a start time
    tic(1)

    kil_chk = threading.Event()
    #if device is NVME type then we will not run self test
    if (deviceType != "NVMe" ):
        printMsg ("start selftest")
		
        try: 
                global SelfTError
		#step 1 Start self-test
		cmd_to_exe1 = "\"%s\" selftest %s %s -f" % (tsbdrvPath,testtype,DeviceId)
		res1 = runCmd(cmd_to_exe1)

		# Check that command executed successfully.
		checkForSuccess(res1)
	      
		#step 2 poll for self-test completion.
		pollforCompletion()
		#Check status of the self test result after completion.
		cmd_to_exe2 = "\"%s\" selftest result %s -t" % (tsbdrvPath,DeviceId)
		res2 = runCmd(cmd_to_exe2)
		#print res2
		dict1 =  parseOutput(res2["OUTPUT"])
		
		selftestattr = 0
		for dictKey in dict1.keys():
		    if re.search(r'test_status$',dictKey,re.I):
			if (dict1[dictKey] == 'Completed'):
			    printMsg ("Self test result check passed")
			    selftestattr = 1
			    break
			else:
			    printErr("Self Test result check failed")

		if selftestattr:
		    pass
		else:
		    printErr("Self Test result failed")

		cmd_to_exe2_1 = "\"%s\" selftest result %s -xml" % (tsbdrvPath,DeviceId)
		res2 = runCmd(cmd_to_exe2_1)
		checkForSuccess(res2)

        except Exception as e:
            """ Ignore error/exception and move ahead 
                with execution of next block of code as we wanted 
		to capture errors/failure from multiple commands. 			
            """ 
            SelfTError.append(e)
            pass
    
    # Step 3 : Check self-test result
    cmd_to_exe3 = "\"%s\" smart info %s -src all -tc -t" % (tsbdrvPath,DeviceId)
    res3 = runCmd(cmd_to_exe3)
    checkForSuccess(res3)
    dict2 =  parseOutput(res3["OUTPUT"])
    smartattr = 0
    for dictKey, dictValue in dict2.items():
        if (dictValue == 'SMART trip failure'):
            smartTripValue = dict2[dictKey.replace("field", "value")]
            if (smartTripValue == '0'):
                printMsg ("SMART Attribute Values check passed")
                smartattr = 1
            else:
                printErr ("SMART Attribute Values check failed")

    if smartattr:
        pass
    else:
        printErr ("SMART Attribute Values check failed")

    # Step 4:Comprehensive error log check

    cmd_to_exe4 = "\"%s\" smart errors %s -t" % (tsbdrvPath,DeviceId)
    res4 = runCmd(cmd_to_exe4)
    checkForSuccess(res4)
    dict3 =  parseOutput(res4["OUTPUT"])
    #check the error information if the device is the ATA
    if (deviceType == "ATA"):
        count = 0
        for dict3Keys, dict3Values in dict3.items():
            matchObj = re.match( r'.*__comprehensive_error_information__total',dict3Keys, re.I)
            if (matchObj and dict3Values == '0'):
                count = count + 1
                break
        if count == 1 :
            printMsg("Comprehensive error log check passed")
        else:
            printErr ("Comprehensive error log check failed")
    #Check if the device is the SCSI
    elif (deviceType == "SCSI"):
        count = 0
        for dict3Keys, dict3Values in dict3.items():
            matchObj = re.match( r'.*__scsi_lba_defect_list__primary_defects__total',dict3Keys, re.I)
            matchObj1 = re.match( r'.*scsi_lba_defect_list__grown_defects__total',dict3Keys, re.I)
            if (matchObj or matchObj1 and dict3Values == '0'):
                count = count + 1
        if count == 2 :
            printMsg("Comprehensive error log check passed")
        else:
            printErr ("Comprehensive error log check failed")
    elif (deviceType == "NVMe"):
        pass
    else:
        printErr ("Error while getting the device type")

    #take end time
    runtime = toc(1,"TRUE")
    second = (str(runtime).split(':'))[2]
    minute = (str(runtime).split(':'))[1]
    hour = (str(runtime).split(':'))[0]
    timeList = []
    timeList.append(hour)
    timeList.append(minute)
    timeList.append(second)
    #check the time required is less than 4 min
    if ((int (hour) != int(0)) or (int (minute) >=  int(selftesttimeout)) ):
        printErr ("Self Test Timeout")
    else:
        printMsg ("Time required for script to complete is: %s hours %s minute %s seconds" %(hour,minute,second))
        loginfo ("judgement pass")
        return timeList

    today = []
    today = time.localtime()[0:6]
    timestr = "%02d_%02d_%04d_%02d_%02d_%02d" % (today[2], today[1], today[0], today[3], today[4], today[5])
    filename = "selftest_logs_" + timestr
    logHdl = open(filename,"w")
    return logHdl

# main program starts here

kil_chk = threading.Event()
#read command line argument
cmdargs = readcmdarg()
Device = cmdargs.device_name
device_type = cmdargs.device_type
testtype = cmdargs.test_type
selftesttimeout = cmdargs.timeout
polltime = cmdargs.polling_time

#if user mentioned the testtype as the short then default value for timeout will be 10 Minutes and for polling time will be 10 Sec.
if re.match(r'^short$',testtype,re.I):
    if selftesttimeout == None:
       selftesttimeout = 600
    if polltime == None:
       polltime = 10

#if user mentioned the testtype as the long then default value for timeout will be 4 Hrs. and for polling time will be 60 Sec.
if re.match(r'^long$',testtype,re.I):
    if selftesttimeout == None:
       selftesttimeout = 14400
    if polltime == None:
       polltime = 60

Devices = []
logsdevices = []
outDict = {}

#start the logging
today = []
today = time.localtime()[0:6]
timestr = "%02d_%02d_%04d_%02d_%02d_%02d" % (today[2], today[1], today[0], today[3], today[4], today[5])
filename = "selftest_logs_" + timestr
logHdl = open(filename,"w")

#list all the devices by executing the query all command
cmd_query0 = "tsbdrv query all"
Queryres0 = runCmd(cmd_query0)
checkForSuccess(Queryres0)
Queryout0 = Queryres0["OUTPUT"]
print (Queryout0)

# check if all is given if given execute on the all the devices
if re.match(r'^all$',Device,re.I):
    Devices = getAllDevices()
elif re.search(r',',Device):
    Devices = Device.split(',')
else:
    Devices.append(Device)

for DeviceId in Devices:
	#Get the device type of the device
	try:
		deviceType = getDeviceType(DeviceId)
	except Exception,e:
		logsdevices.append(DeviceId)
		matchObj = re.match(r'(.+)(TSBERR\d+:.+)',str (e))
		if matchObj:
			outDict[DeviceId] = matchObj.group(2)
		else:
			outDict[DeviceId] = e
		continue
	try:
		#check for the device type sent from the User
		if re.search(r'all',device_type):
			pass
		else:
			if re.search(r',',device_type):
				devices = device_type.split(',')
				if deviceType.lower() in (temp_device.lower() for temp_device in devices):
					pass
				else:
					print "%s device is of type %s.User mentioned other device type hence skipping test for this device"%(DeviceId,deviceType)
					continue
			else:
				if deviceType.lower() == device_type.lower():
					pass
				else:
					print "%s device is of type %s.User mentioned other device type hence skipping test for this device"%(DeviceId,deviceType)
					continue
	except:
		continue
	try:
	   print "***********************************************"
	   print "Test will start for Device %s"%(DeviceId)
	   logsdevices.append(DeviceId)
	   timeList = execute_main(DeviceId)
	   outDict[DeviceId] = timeList
	except Exception,e:
	   matchObj = re.match(r'(.+)(TSBERR\d+:.+)',str (e))
	   if matchObj:
		   outDict[DeviceId] = matchObj.group(2)
	   else:
		   outDict[DeviceId] = e

#print the summary report for all the Devices
global SelfTError
if len(outDict) != 0:
    print "=================Summary Report==================="
    print "Device \t\t Result \t  Details"
    for device in logsdevices:
        if type(outDict[device]) is list:
            print "%s \t PASS \t Self Test duration:%s Min %.2f Sec"%(device,outDict[device][1],float (outDict[device][2]))
        else:
            print "%s \t FAIL \t %s"%(device,outDict[device])
if len(SelfTError) !=0:             
    print device+" \t FAIL \t "+str(SelfTError[0])
else:
    pass	

print "Local log file %s"%(filename)

#stop the logging and exit from the script
logHdl.close()
sys.exit(0)
