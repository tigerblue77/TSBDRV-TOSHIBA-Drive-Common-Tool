#!/usr/bin/python
# -------------------------------------------------------------------------------
# Name:       fw_download_read_log
#
# Purpose:   Update firmware on device and Dump Log Pages from Log Address 0x24
#
# Created:    26/11/2015
#
# Copyright:  Copyright (C) 2017-18 Toshiba Electronic Devices & Storage Corporation. All Rights Reserved.
# Licence:
#
# ------------------------------------------------------------------------------

#!/usr/bin/python
# Import python modules
import sys
import re
import subprocess
import threading
import os
import signal

helpStr = """

Update firmware on device and Dump Log Pages from Log Address 0x24
DeviceId      : Device ID (e.g. sda, sdb)
FwImagePath   : Firmware image/package file path
LogPageRange  : LogPageRange (e.g. 0-100)
DataSaftyFlag : It's optional parameter which forces firmware download even if there is a possibility of
                user data loss. User must pass "-n"

"""
usage = "usage: python %s <DeviceId> <FwImagePath>  \
<LogPageRange(e.g 0-10)> [DataSaftyFlag] %s" % (sys.argv[0], helpStr)

# Creating threading event
kil_chk = threading.Event()

DataSaftyFlag = ''
if len(sys.argv) == 5:
    if (re.match(r'^-n$',sys.argv[4])):
        DataSaftyFlag = sys.argv[4]
    else:
        print usage
        sys.exit(1)


# Check command line arguments, must be 5 including module name
elif len(sys.argv) != 4:
    print usage
    sys.exit(1)

# Parsing the command line arguments
DeviceId = sys.argv[1]
FwImagePath = sys.argv[2]
LogPageRange = sys.argv[3]

# logpage range must be separated by hyphen (-)
if not re.match(r'\d+-\d+', LogPageRange):
    print "LogPage Range is invalid"
    print usage
    sys.exit(1)
else:
    # Check for start range, must be less than end range parameter
    (start, end) = LogPageRange.split("-")
    if (int(start) > int(end)):
         print "Start of range must be less than end"
         print usage
         sys.exit(1)

def cmd_exists(cmd):
    return any(
        os.access(os.path.join(path, cmd), os.X_OK)
        for path in os.environ["PATH"].split(os.pathsep)
    )
#check wheather tsbdrv present on the system

if os.name == "nt":
    if cmd_exists("tsbdrv.exe"):
	   tsbdrvPath = "tsbdrv"
    else:
        #In windows check if parent directory contains the tsbdrv.exe
		path1 = os.getcwd()
		parentPath = os.path.abspath(os.path.join(path1, os.pardir))
		for root, dirs, files in os.walk(parentPath):
			for tsbdrvEXE in files:
				if re.search(r'tsbdrv.exe',tsbdrvEXE):
					tsbdrvPath = os.path.join(root,tsbdrvEXE)
					break
    #If in windows tsbdrv not found in the parent directory then we will exit
    try :
        tsbdrvPath
        print "tsbdrv is installed on the system"
    except NameError:
        print '''We are unable to find the tsbdrv on the system. Please add tsbdrv to the Environmental variables
                 or run the script from the TSBDRV_SCRIPT folder'''
        sys.exit(1)

else:
    #If system is linux we will exit script as tsbdrv is not found
    if cmd_exists("tsbdrv"):
	   tsbdrvPath = "tsbdrv"
    else:
        print "tsbdrv is not installed.Exiting the Script...."
        sys.exit(1)


def _kill_pid_after_timeout(pid):
    """Function to kill the process after set timeout
       Input : process id pid Return : None
    """

    os.kill(pid, signal.SIGTERM)
    # Kill the process with SIGTERM and inform to calling function
    kil_chk.set()
    return


def runCmd(cmd_to_exe):
    """Function to execute command
      Input : command to be executed
      Return : Dictionary of command output, error if any, status
               of execution, timeout error if occurred
    """
    # Timeout set is 70 sec for execution of above command
    timeout = 70
    # Execute command using subprocess module
    run_cmd = subprocess.Popen(cmd_to_exe, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, shell=True)
    # Get the pid of process
    pid = run_cmd.pid
    # start watchdog,if command taking longer time than timeout kill process
    watchdog = threading.Timer(timeout, _kill_pid_after_timeout, args=(pid, ))
    watchdog.start()
    # Get the command output and error in any from process
    (cmd_output, cmd_err) = run_cmd.communicate()
    status = run_cmd.wait()
    watchdog.cancel()
    timeout_err = kil_chk.isSet()
    kil_chk.clear()
    res = {"OUTPUT": cmd_output, "ERROR": cmd_err, "STATUS": status,
           "TIMEOUTERR": timeout_err}
    return res

# First command is "tsbdrv firmware download"
cmd_to_exe1 = "\"%s\" firmware download %s %s %s \
--silent" % (tsbdrvPath,DeviceId, FwImagePath, DataSaftyFlag)

print "Command to be executed - ", cmd_to_exe1
res1 = runCmd(cmd_to_exe1)
# Check that command executed successfully
if (res1["STATUS"] == 0):
    print "Output :\n", res1["OUTPUT"]

else:
    # Check for error or timeout in case of error
    if (res1["ERROR"]):
        print "Error :\n", res1["ERROR"]
    elif (res1["TIMEOUTERR"]):
        print "Timeout error occurred"
    # if failed, script should exit without further execution
    sys.exit(1)

# Second command is "tsbdrv logs read" for log-pages provided by user
# Read all the log pages from log address
for logpage in range(int(start), int(end)+1):
    cmd_to_exe2 = "\"%s\" logs read %s %s -sp %s" % (tsbdrvPath,DeviceId, "0x24", logpage)
    print "Command to be executed - ", cmd_to_exe2
    res2 = runCmd(cmd_to_exe2)
    if (res2["STATUS"] == 0):
        print "Output :\n", res2["OUTPUT"]
    else:
        # Check for error or timeout in case of error
        if (res2["ERROR"]):
            print "Error :\n", res2["ERROR"]
        elif (res2["TIMEOUTERR"]):
            print "Timeout error occurred"
# Exit from script
sys.exit(0)
