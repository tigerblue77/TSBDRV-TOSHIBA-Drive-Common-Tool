#!/usr/bin/python
# -------------------------------------------------------------------------------
# Name:        read_multiple_log_pages
#
# Purpose:     Get the log pages for the device mentioned
#
# Created:     26/11/2015
#
# Copyright:   Copyright (C) 2017-18 Toshiba Electronic Devices & Storage Corporation. All Rights Reserved.
#
# Licence:
#
# -------------------------------------------------------------------------------


# Import python modules
import sys
import re
import subprocess
import threading
import os
import signal
import pdb
tsbdrvPath = ""
helpStr = """"

Read Log Pages
"""
usage = "usage: python %s <DeviceId> \
<LogAddress(Page address from the 'tsbdrv logs directory <DeviceId>' command or \n \
User can mention 'all' to print all logs from respective page addresses)>" % (sys.argv[0])

# Check command line variables
if len(sys.argv) != 3:
    print usage
    sys.exit(1)
else:
    DeviceId = sys.argv[1]
    LogAddress = sys.argv[2]

# Creating threading event
kil_chk = threading.Event()

def cmd_exists(cmd):
     return any(
        os.access(os.path.join(path, cmd), os.X_OK)
        for path in os.environ["PATH"].split(os.pathsep)
    )

#check wheather  tsbdrv present on the system

if os.name == "nt":
    if cmd_exists("tsbdrv.exe"):
	   tsbdrvPath = "tsbdrv"
    else:
        #In windows check if parent directory contains the tsbdrv.exe
		path1 = os.getcwd()
		parentPath = os.path.abspath(os.path.join(path1, os.pardir))
		for root, dirs, files in os.walk(parentPath):
			for tsbdrvEXE in files:
				if re.search(r'tsbdrv.exe',tsbdrvEXE):
					tsbdrvPath = os.path.join(root,tsbdrvEXE)
					break
    #If in windows tsbdrv not found in the parent directory then we will exit
    try :
        tsbdrvPath
        print "tsbdrv is installed on the system"
    except NameError:
        print '''We are unable to find the tsbdrv on the system. Please add tsbdrv to the Environmental variables
                 or run the script from the TSBDRV_SCRIPT folder'''
        sys.exit(1)

else:
    #If system is linux we will exit script as tsbdrv is not found
    if cmd_exists("tsbdrv"):
	   tsbdrvPath = "tsbdrv"
    else:
        print "tsbdrv is not installed.Exiting the Script...."
        sys.exit(1)


def _kill_pid_after_timeout(pid):
    """Function to kill the process after set timeout

      Input : process id pid Return : None
    """
    os.kill(pid, signal.SIGTERM)
    # Kill the process with SIGTERM and inform to calling function
    kil_chk.set()
    return


def runCmd(cmd_to_exe):
    """Function to excute command
      Input : command to be executed
      Return : Dictionary of command ouput, error if any, status
               of execution, timeout error if occured
    """

    print "Command to be executed - " + cmd_to_exe

    # Timeout set is 70 sec for execution of above command
    timeout = 70
    # Execute command using subprocess module
    run_cmd = subprocess.Popen(cmd_to_exe, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, shell=True)
    # Get the pid of process
    pid = run_cmd.pid
    # start watchdog,if command taking longer time than timeout kill process
    watchdog = threading.Timer(timeout, _kill_pid_after_timeout, args=(pid, ))
    watchdog.start()
    # Get the command output and error in any from process
    (cmd_output, cmd_err) = run_cmd.communicate()
    status = run_cmd.wait()
    watchdog.cancel()
    timeout_err = kil_chk.isSet()
    kil_chk.clear()
    res = {"OUTPUT": cmd_output, "ERROR": cmd_err, "STATUS": status,
           "TIMEOUTERR": timeout_err}
    return res

def checkForSuccess(res1):
    '''Function to check the failure status of command
       If command is failed then sript will exit without further execution
    '''
    if (res1["STATUS"] == 0):
           print "Output :" + res1["OUTPUT"]
    else:
        # Check for error or timeout in case of error
        if (res1["ERROR"]):
             print ("TSBDRV Error " + res1["ERROR"])
        elif (res1["TIMEOUTERR"]):
             print ("Command Time-out error occurred")
    # if failed, script should exit without further execution

def parseOutput(output):
    '''Function is used to parse the tsbdrv command output
       returns the dictionary formed as per the command output
    '''
    dict = {}
    outarray1 = output.rstrip().split(';')
    for out in outarray1:
        if out:
            outarray2 = out.split('=')
            dict[outarray2[0]] = outarray2[1]
    return dict

def getAddr(terseOut):
    """
    returns the array of the valid address
    
    Input : logs directory terse output

    Retrun : hash containing array of log_page and page_count
    """
    pageInfo = {}
    pageInfo['page_count'] = []
    pageInfo['log_page'] = []
    compStr = re.compile(r".*log_page")
    for k,v in terseOut.items():
        if v == "0":
            pageInfo['log_page'].append(v)
            pageInfo['page_count'].append(terseOut[k.replace("log_page","page_count")])
        if compStr.search(k):
            if v not in pageInfo['log_page']:
                pageInfo['log_page'].append(v)
                try:
                    pageInfo['page_count'].append(terseOut[k.replace("log_page","page_count")])
                except KeyError:
                    pageInfo['page_count'].append("")
    return pageInfo
 
#execute the logs directory command to get the page address 
cmd_to_exe1 = "\"%s\" logs directory %s -t" % (tsbdrvPath,DeviceId)
res1 = runCmd(cmd_to_exe1)

if (res1["ERROR"]):
    print ("TSBDRV Error " + res1["ERROR"])
    sys.exit(1)
elif (res1["TIMEOUTERR"]):
    print ("Command Time-out error occurred")
    sys.exit(1)

terseOut = parseOutput(res1["OUTPUT"])
validAddr = getAddr(terseOut)
validAddrList = validAddr["log_page"]
LogAddr = []
LogAddrValues = []
#check if user mentioned output
if re.match(r'^all$',LogAddress,re.I):
    LogAddr = validAddrList 
elif re.search(r',',LogAddress):
    LogAddrValues = LogAddress.split(',')
    for values in LogAddrValues:
        matchObj = re.match( r'.+x.+',values, re.I)
        if matchObj :
            dec = int(values, 16)
            LogAddr.append(str(dec))
        else :
            LogAddr.append(values)
else:
    matchObj = re.match( r'.+x.+',LogAddress, re.I)
    if matchObj :
        dec = int(LogAddress, 16)
        LogAddr.append(str(dec))
    else :
        LogAddr.append(LogAddress)

for logAddress in LogAddr:
    if logAddress in validAddrList:
        subpageCount = validAddr["page_count"][validAddrList.index(logAddress)]
        subpageRange = "0" + "-" + str(int(subpageCount)-1)
        cmd_to_exe2 = "\"%s\" logs read %s %s -sp %s" % (tsbdrvPath,DeviceId,logAddress,subpageRange)
        res2 = runCmd(cmd_to_exe2)
        checkForSuccess(res2)
    else:
       print "%s log address is not valid Please check the logs directory output for more info"%(logAddress)

sys.exit(0)
