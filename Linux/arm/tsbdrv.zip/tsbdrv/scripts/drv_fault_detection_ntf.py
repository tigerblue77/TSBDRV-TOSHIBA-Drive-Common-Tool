#!/usr/bin/python
"""
#-------------------------------------------------------------------------------
#
# Name:  drv-fault-detection.py
#
# Purpose: 1.   This will list all drives and ask user to select list of drives to run test
#          2.   Perform NTF test 
#          3.   List failed drives out of selected drives (Along with Serial number)
#          4.   Optionally run error dup test to see if bad blocks can be recovered
#          5.   Log results and exit.         
#
# Created: 17/Dec/2018
# HowTo: Run following command from directory where script is stored:
#           > python drv-fault-detection-ntf.py 
#       Note: - Read command line messages carefully. 
#             - Logs will be created in current working directory.
# Copyright:  Copyright (C) 2018-19 Toshiba Electronic Devices & Storage Corporation. All Rights Reserved.
# License:
#
#------------------------------------------------------------------------------
"""

# Import python modules
import sys
import os 
import xml.etree.ElementTree as ET
import subprocess
from datetime import datetime
import shutil
import re
import mmap
import signal

# Test parameter variables.
ntf_selftest_type = 1
ntf_rand_run_duration_min = 10 
ntf_seq_run_drv_percentage = 25

# These are the constant values used within the scripts. 
DRV_TOOL = "tsbdrv"
QUERY_CMD = DRV_TOOL + " query all -xml"
DIAG_NTF_CMD_PART1 = DRV_TOOL + " diagtest ntf "
DIAG_NTF_CMD_PART2 = " --self_test "+ str(ntf_selftest_type) +" --dur "+ str(ntf_rand_run_duration_min) +" -c "+ str(ntf_seq_run_drv_percentage) +"  --log_check  --logdir " 
DIAG_ERRDUP_CMD_PART1 = DRV_TOOL + " diagtest errdup "
DIAG_ERRDUP_CMD_PART2 = " --rewrite --exclusive --logdir " 
LOG_PATH_SEARCH_START_MSG = "See log file \'"
LOG_PATH_SEARCH_END_MSG = "\' for details."

#List of Global Variables.
current_run_log_path = ""
log_path_exist = False
subprocess_output_file_name = os.path.join(os.getcwd(), "temp.stdout" ) 

"""
# This function creates log directory with current time stamp.
""" 
def createLogDir():
    global current_run_log_path
    global log_path_exist
    
    current_run_log_path = os.path.join(os.getcwd(), (str(datetime.now()).replace(":", ".")).replace(" ", "_"))  
    try:  
        os.mkdir(current_run_log_path)
    except OSError:  
        print ("Creation of the log directory %s failed" % current_run_log_path)
    else:  
        log_path_exist = True  
        
    return current_run_log_path
    
"""
# This function execute DRV Tool Command on System and capture command response.
"""
def executeCommand(cmd_to_exe, need_full_output=False):
    response = {}
    global subprocess_output_file_name
    
    if need_full_output:
        run_cmd = subprocess.Popen(cmd_to_exe, stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)
        (cmd_output, cmd_err) = run_cmd.communicate()
        status = run_cmd.wait()
        response = {"COMMAND": cmd_to_exe,"OUTPUT": cmd_output, "ERROR": cmd_err, "STATUS": status}
    else:
        run_cmd = ''
        with open(subprocess_output_file_name, "w+") as fout:
            run_cmd = subprocess.Popen(cmd_to_exe, stdout=fout,stderr=subprocess.PIPE, shell=True)
            
        (cmd_output, cmd_err) = run_cmd.communicate()
        status = run_cmd.returncode
        
        out_file_handle = open(subprocess_output_file_name)
        memory_map_of_out_file = mmap.mmap(out_file_handle.fileno(), 0, access=mmap.ACCESS_READ)
        stringFound = re.search(LOG_PATH_SEARCH_START_MSG + '(.*)' + LOG_PATH_SEARCH_END_MSG, memory_map_of_out_file)
        out_file_handle.close()
        
        if stringFound:
            cmd_output = stringFound.group(0)
        else: 
            cmd_output = "NO OUTPUT FILE AVAILABLE: --logdir option is not given with this command!"
            
        response = {"COMMAND": cmd_to_exe,"OUTPUT": cmd_output, "ERROR": cmd_err, "STATUS": status}
    return response

"""
# This method parse xml output and retrieves values given in xml_tag_str_list.
# It returns Drive Details for all drives attached to system.
"""    
def helperParseXmlOutput(xml_data, xml_tag_str_list):
    drv_details = []
    #available_drv_details = []
    lock_key = 'LOCKED'
    
    f = open( 'in-temp-xml.xml', 'w' )
    f.write(xml_data)
    f.close()

    tree = ET.ElementTree(file='in-temp-xml.xml')

    all_elem = tree.getiterator()
    drv_dict = {}
    data_complete_flag = 0
    
    for elem in all_elem:
        if elem.tag == xml_tag_str_list[0]:
            drv_dict[xml_tag_str_list[0]] = elem.text
            
        if ((elem.tag == xml_tag_str_list[1])): 
            drv_dict[xml_tag_str_list[1]] = elem.text
            
        if ((elem.tag == xml_tag_str_list[2])):  
            drv_dict[xml_tag_str_list[2]] = elem.text
            
        if ((elem.tag == xml_tag_str_list[3])):
            if xml_tag_str_list[0] in drv_dict.keys():  
                if xml_tag_str_list[1] in drv_dict.keys():          
                    if xml_tag_str_list[2] in drv_dict.keys():
                        drv_dict[xml_tag_str_list[3]] = elem.text
                        data_complete_flag = True
            
        if data_complete_flag :
            drv_details.append(drv_dict)
            drv_dict = {}
            data_complete_flag = False
    
    if os.path.exists('in-temp-xml.xml'):
        os.remove('in-temp-xml.xml')
    else:
        print("The file " + "in-temp-xml.xml" + " does not exist!") 

    return drv_details

"""
# This method prints List of drives attached to system in following format:
# "PHYSICAL_DRIVE", "SERIAL_NUMBER", "MODEL_NUMBER", "DEV_TYPE"
"""
def printDriveTable(driveDetailsList, query_tag_list):
    
    headings = []
    column_width = []
    marker_width = 0
    
    max_list = maxWidthOfEachColumn(driveDetailsList, query_tag_list)
    
    for item in max_list:
        headings.append(str(item.keys()[0]))
        column_width.append(str(item.values()[0]))
        marker_width = marker_width + item.values()[0]
        
    formatter = '%-' + column_width[0] + 's%-' + column_width[1] + 's%-' + column_width[2] +'s%-' + column_width[3]+ 's'
    # print header:
    print '-' * marker_width
    print formatter % (headings[0], headings[1], headings[2], headings[3])
    print '-' * marker_width
    
    # print drive info:
    for item in driveDetailsList:
        print formatter % (item[headings[0]], item[headings[1]], item[headings[2]], item[headings[3]])
    print '-' * marker_width + '\n'     
    return 0

"""
# this helper method calculates maximum width of each column for drive list. 
"""
def maxWidthOfEachColumn(driveDetailsList, query_tag_list):
    max_list = []
    for header in query_tag_list:
        item_list = []
        column_width_dict = {}
        for dict_entry in driveDetailsList:
            if dict_entry[header] :
                item_list.append(len(dict_entry[header]))
        item_list.append(len(header))
        column_width_dict[header] = (max(item_list)) + 1
        max_list.append(column_width_dict)

    return max_list

"""
# This generic method does following action:
#   - Print Message for user.
#   - Wait for user response.
#   - Parse the drive input from user.
#   - Creates non-duplicated list of drives to be tested.
"""
def messageForUserAndGetUserInput(question_string, driveDetailsList):
    drives_to_test = []
    
    drive_list_from_user = [x.strip() for x in raw_input(question_string).split(',')]
    if drive_list_from_user :
        drive_list_from_user = list(set(drive_list_from_user)) # removes duplicate entry

        for serial_num in drive_list_from_user:
            if ((serial_num == 'ALL') or (serial_num == 'all')):
                drives_to_test = driveDetailsList
            else:           
                for drive in driveDetailsList:
                    this_item_exist = [item for item in drives_to_test if ((item["PHYSICAL_DRIVE"] == serial_num) or (item["SERIAL_NUMBER"] == serial_num))]
                    if not this_item_exist:
                        if (drive['SERIAL_NUMBER'] == serial_num): 
                            drives_to_test.append(drive)
                        elif (drive['PHYSICAL_DRIVE'] == serial_num):
                            drives_to_test.append(drive)
        
    return drives_to_test

"""
# This method creates NTF command of DRV tool and send it for execution.
"""
def startNTFTest(drive_name):    
    cmd_string = DIAG_NTF_CMD_PART1 + drive_name + DIAG_NTF_CMD_PART2 + current_run_log_path + " " 
    ntf_response = executeCommand(cmd_string)
    
    return ntf_response

"""
# This method creates Error Duplication command of DRV tool and send it for execution.
"""
def startErrDupTest(drive_name):
    cmd_string = DIAG_ERRDUP_CMD_PART1 + drive_name + DIAG_ERRDUP_CMD_PART2 + current_run_log_path + " " 
    errdup_response = executeCommand(cmd_string)

    return errdup_response
 
"""
# This method prints test headings on console.
""" 
def printBanner(bannerMsg):
    print "\n#" + ('{:-^78}'.format(bannerMsg)) + "#\n"    
    return 0

"""
# This method prints demarcation line on console.
"""     
def deviderBanner():
    print "#" + ("-" * 78) + "#"
    return 0

"""
# This method formats and prints test status for each drive.
""" 
def printDriveTestStatusBanner(dut, msg,status):
    print('{0:.<60}.{1:10}'.format(( dut['SERIAL_NUMBER'] + "(" + dut['PHYSICAL_DRIVE'] + "): " + msg ) , status))
    return 0    

"""
# This method handles NTF test execution and result consolidation for NTF test.
""" 
def ntfTestAndOutput(drives_under_test):
    Failed_drives = []
    Success_drives = []
    Failed_drives_info = []
    NTF_result = [] 
    
    #Run NTF tests on drives
    printBanner(" NTF Test Execution ")
    for drive in drives_under_test:
        ntf_dict = {}
        ntf_dict['DRIVE_DETAILS'] = drive
        printDriveTestStatusBanner(drive, "NTF Test ","Started")
        ntf_dict['NTF_CMD_RESPONSE'] = startNTFTest(drive['PHYSICAL_DRIVE'])
        if ntf_dict['NTF_CMD_RESPONSE']['STATUS'] == 0 : 
            printDriveTestStatusBanner(drive, "NTF Test ", "Passed\n")
        else:
            printDriveTestStatusBanner(drive, "NTF Test ", "Failed\n")
            
        # Rename NTF Log and prepend with Drive Serial Number.
        renamelogFile(getLogFileName(str(ntf_dict['NTF_CMD_RESPONSE']['OUTPUT'])), drive['SERIAL_NUMBER'], "ntftest")        
        NTF_result.append(ntf_dict)
    
    # Find out NTF failed drives:
    for drv in NTF_result:
        if drv['NTF_CMD_RESPONSE']['STATUS'] != 0 :
            Failed_drives.append(drv)
        elif drv['NTF_CMD_RESPONSE']['STATUS'] == 0 :
            Success_drives.append(drv["DRIVE_DETAILS"])
            
    if Failed_drives:# NULL CHECK
        printBanner(" NTF Test FAILED for following drives ")
        for drv in Failed_drives:
            print (drv["DRIVE_DETAILS"]['SERIAL_NUMBER'] + "(" + drv['DRIVE_DETAILS']['PHYSICAL_DRIVE'] + "): " + drv['NTF_CMD_RESPONSE']['ERROR'])
            Failed_drives_info.append(drv["DRIVE_DETAILS"])
    return Success_drives, Failed_drives_info

"""
# This method handles error duplication and recovery test execution and result consolidation for test.
"""     
def errdupTestAndOutput(drives_for_errdup, query_tag_list, drives_under_test):
    ERRDUP_result = []
    printBanner("Error Duplication & Recovery Test Execution")     
    for drv in drives_for_errdup:
        errdup_dict = {}
        errdup_dict['DRIVE_DETAILS'] = drv
        printDriveTestStatusBanner(drv, "ErrorDup Test ", "Started")
        errdup_dict['ERR_DUP_CMD_RESPONSE'] = startErrDupTest(drv['PHYSICAL_DRIVE'])
        if errdup_dict['ERR_DUP_CMD_RESPONSE']['STATUS'] == 0 : 
            printDriveTestStatusBanner(drv, "ErrorDup Test ", "Passed\n")
        else:
            printDriveTestStatusBanner(drv, "ErrorDup Test ", "Failed\n")
        renamelogFile(getLogFileName(str(errdup_dict['ERR_DUP_CMD_RESPONSE']['OUTPUT'])), drv['SERIAL_NUMBER'], "errordup")    
        ERRDUP_result.append(errdup_dict)

    # Find out ERR DUP failed drives:
    Failed_drives = [] 
    printBanner(" ERROR Duplication & Recovery Test FAILED for following drives ")
    for drv in ERRDUP_result:
        failed_drv_index = len(drives_under_test) + 1    
        if drv['ERR_DUP_CMD_RESPONSE']['STATUS'] != 0 :
            Failed_drives.append(drv['DRIVE_DETAILS'])
            print (drv["DRIVE_DETAILS"]['SERIAL_NUMBER'] + "(" + drv['DRIVE_DETAILS']['PHYSICAL_DRIVE'] + "): " + drv['ERR_DUP_CMD_RESPONSE']['ERROR'])
            for drives in drives_under_test:
                if drives['PHYSICAL_DRIVE'] == drv['DRIVE_DETAILS']['PHYSICAL_DRIVE']:
                    failed_drv_index = drives_under_test.index(drives)
                    break
            del drives_under_test[failed_drv_index]  

    return drives_under_test, Failed_drives

"""
# This method search for test log file name in command response and returns the same to calling method.
""" 
def getLogFileName(cmd_output_str):
    result = re.search(LOG_PATH_SEARCH_START_MSG + '(.*)' + LOG_PATH_SEARCH_END_MSG, cmd_output_str)
    return result.group(1)

"""
# This method renames and moves the test log file in test directory.
"""     
def renamelogFile(oldLogAbsPath, drvSrNo, testName):
    file_name = (os.path.basename(oldLogAbsPath))
    new_file_with_abs_path = os.path.join(current_run_log_path , ("drv-" + drvSrNo + "-" + testName + "-" + file_name) ) 
    shutil.move(oldLogAbsPath, new_file_with_abs_path)  
    return 0

"""
# This function gracefully handle keyboard interrupt.
"""
def test_interrupt_handler(sig, frame):
        print('\nTest aborted by keyboard interrupt [Ctrl+C]')
        sys.exit(0)
signal.signal(signal.SIGINT, test_interrupt_handler)


"""
# This method handles complete flow of Drive Test.
"""     
def main():
    global log_path_exist, subprocess_output_file_name
    success_drv_list = []
    failed_drv_list = []
    drives_for_errdup = []
    drives_under_test = []
    driveDetails = []
    execute_script = True
    
    arguments = sys.argv[1:]

    # Help Menu Display.
    if(len(arguments) != 0):
        execute_script = False
        """
        ntf_selftest_type = 1
        ntf_rand_run_duration_min = 10 
        ntf_seq_run_drv_percentage = 25
        """
        if(arguments[0] == '-h' or arguments[0] == '--help' ):
            print "\nSummary: This test performs NTF(Check smart attributes and errors, Smart self-test short, 25% sequential read, 10 minutes random read) test on drives. This test also facilitate users option to run Error Duplication & Recovery test.\n\n\
Usage: python drv-fault-detection-ntf.py \n\n\
Test Configuration: Following parameters at top of the script can be modified to change the NTF test configuration:\n\
    - ntf_selftest_type = 1             [Value: (0:none , 1:short, 2:long), If '0' then Smart Self Test will not run.]\n\
    - ntf_rand_run_duration_min = 10    [Value: (Min: 0, Max: 30), If '0' then random read will not run.]\n\
    - ntf_seq_run_drv_percentage = 25   [Value: (Min: 0, Max: 100),If '0' then sequential read will not run.]\n\n"              
        else:
            print "kindly run script with '-h' or '--help' option to see help menu. For test execution no command line arguments required."
            
    # test execution.
    if(execute_script):     
        query_tag_list = ["PHYSICAL_DRIVE", "SERIAL_NUMBER", "MODEL_NUMBER", "DEV_TYPE"]
        usr_input = False
        # Create Log directory first.
        createLogDir()
        
        deviderBanner()
        printBanner(" TSB Tool For Identifying and Handling Drive Fault ")
        # List all drives on system using "query command"
        cmd_output = executeCommand(QUERY_CMD, True)
        
        # Parse Query xml and retrieve Drive ID, Modal Number and Serial Number.
        driveDetails = helperParseXmlOutput(cmd_output.get("OUTPUT"), query_tag_list) 

        # Print data in tabular format and take user input.
        if driveDetails:
            printDriveTable(driveDetails, query_tag_list)
        
            #Seek user input for drive serial number or all drives.
            drives_under_test = messageForUserAndGetUserInput("Kindly enter comma separated drive serial numbers e.g. ASDDXX123G, XGPDDXX123K\
            \nOR Drive ID e.g. /dev/sda, /dev/sdc, /dev/nvme0\nOR Type all/ALL to select all devices: ", driveDetails)

        #Run NTF Test on all drives 
        if drives_under_test:
            usr_input = True
            success_drv_list, failed_drv_list = ntfTestAndOutput(drives_under_test)
        
        #Seek user input for drive serial number or all drives.
        if failed_drv_list:
            print "WARNING: Error Duplication and Recovery Test can cause Data Loss!"
            drives_for_errdup = messageForUserAndGetUserInput("Kindly enter comma separated drive serial numbers e.g. ASDDXX123G, XGPDDXX123K \nOR Drive ID e.g. /dev/sda, /dev/sdc, /dev/nvme0 \nOR Type all/ALL to select all Failed devices for Error Duplication Test\
            \nOR Press [Enter] To skip this test.: ", failed_drv_list)
        
        #Run Error Dup on selected drives.
        if drives_for_errdup:
            success_drv_list, failed_drv_list = errdupTestAndOutput(drives_for_errdup, query_tag_list, drives_under_test)
        
        #Print list of Successful drives in tabular format or drives which do not failed errdup test
        printBanner("List of Successful Drives")
        if success_drv_list:
            printDriveTable(success_drv_list, query_tag_list) 
        else:
            print "There are no Drives To List Here."
            
        #Print list of Failed drives in tabular format or drives which do not failed errdup test
        printBanner("List of Failed Drives")        
        if failed_drv_list:
            printDriveTable(failed_drv_list, query_tag_list)
        else:
            print "There are no Drives To List Here.\n"    
        
        if (log_path_exist and usr_input):
            print "\nKindly Check Test Log at " + current_run_log_path + "."

        # Remove temp files.
        if os.path.exists(subprocess_output_file_name):
            os.remove(subprocess_output_file_name)      
    return 0


if __name__ == '__main__':
    main()