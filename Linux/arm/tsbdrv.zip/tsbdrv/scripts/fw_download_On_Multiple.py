#!/usr/bin/python
# -------------------------------------------------------------------------------
# Name:  fw_download_On_Multiple.py
#
# Purpose: To download firmware on requested number of devices with respective
#          firmware file.
#
# Created: 15/Nov/2016
#
# Copyright:  Copyright (C) 2017-18 Toshiba Electronic Devices & Storage Corporation. All Rights Reserved.
# Licence:
#
# ------------------------------------------------------------------------------
# Import python modules
import sys
import re
import subprocess
import threading
import os
import signal

helpStr = """

Update firmware on devices with respective firmware file.

Config_File   : Text file which contains comma separated list of devices & respective firmware separated by colon(:). 	
Sample configuration file should looks like,

sda,sdc:/tmp/FW/SAS/MG03SCA300/H2DG09.BIN
sdd,sde,sdh:/tmp/FW/SAS/MG03SCA200/H2DG09.BIN

DataSaftyFlag : It's optional parameter which forces firmware download even if there is a possibility of
                user data loss. User must pass "-n"
"""

usage = "usage: python %s <Config_File> \
[DataSaftyFlag] %s" % (sys.argv[0], helpStr)


# Creating threading event
kil_chk = threading.Event()

DataSaftyFlag = ''
if len(sys.argv) == 3:
    if (re.match(r'^-n$',sys.argv[2])):
        DataSaftyFlag = sys.argv[2]
    else:
        print usage
        sys.exit(1)

# Check command line arguments, must be 3 including module name
elif len(sys.argv) != 2:
    print usage
    sys.exit(1)

def cmd_exists(cmd):
    return any(
        os.access(os.path.join(path, cmd), os.X_OK)
        for path in os.environ["PATH"].split(os.pathsep)
    )
#check wheather tsbdrv present on the system

if os.name == "nt":
    if cmd_exists("tsbdrv.exe"):
           tsbdrvPath = "tsbdrv"
    else:
        #In windows check if parent directory contains the tsbdrv.exe
                path1 = os.getcwd()
                parentPath = os.path.abspath(os.path.join(path1, os.pardir))
                for root, dirs, files in os.walk(parentPath):
                        for tsbdrvEXE in files:
                                if re.search(r'tsbdrv.exe',tsbdrvEXE):
                                        tsbdrvPath = os.path.join(root,tsbdrvEXE)
                                        break
    #If in windows tsbdrv not found in the parent directory then we will exit
    try :
        tsbdrvPath
        print "tsbdrv is installed on the system"
    except NameError:
        print '''We are unable to find the tsbdrv on the system. Please add tsbdrv to the Environmental variables
                 or run the script from the TSBDRV_SCRIPT folder'''
        sys.exit(1)

else:
    #If system is linux we will exit script as tsbdrv is not found
    if cmd_exists("tsbdrv"):
           tsbdrvPath = "tsbdrv"
    else:
        print "tsbdrv is not installed.Exiting the Script...."
        sys.exit(1)


def _kill_pid_after_timeout(pid):
    """Function to kill the process after set timeout
       Input : process id pid Return : None
    """

    os.kill(pid, signal.SIGTERM)
    # Kill the process with SIGTERM and inform to calling function
    kil_chk.set()
    return


def runCmd(cmd_to_exe):
    """Function to execute command
      Input : command to be executed
      Return : Dictionary of command output, error if any, status
               of execution, timeout error if occurred
    """
    # Timeout set is 70 sec for execution of above command
    timeout = 70
    # Execute command using subprocess module
    run_cmd = subprocess.Popen(cmd_to_exe, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, shell=True)
    # Get the pid of process
    pid = run_cmd.pid
    # start watchdog,if command taking longer time than timeout kill process
    watchdog = threading.Timer(timeout, _kill_pid_after_timeout, args=(pid, ))
    watchdog.start()
    # Get the command output and error in any from process
    (cmd_output, cmd_err) = run_cmd.communicate()
    status = run_cmd.wait()
    watchdog.cancel()
    timeout_err = kil_chk.isSet()
    kil_chk.clear()
    res = {"OUTPUT": cmd_output, "ERROR": cmd_err, "STATUS": status,
           "TIMEOUTERR": timeout_err}
    return res

Dev_lst = []
DevErr_dict = {}
if os.path.isfile(sys.argv[1]):
	fp = open(sys.argv[1],"r")

	for line in fp:
		line=line.rstrip()
		groups = line.split(':')
		DevFRM = ':'.join(groups[:1]), ':'.join(groups[1:])
		Device = DevFRM[0].replace(',',' ')
		Firmware = DevFRM[1]
	
		for dev in Device.split():
			cmd_to_exe1 = "\"%s\" firmware download %s %s %s -s" % (tsbdrvPath, dev, Firmware, DataSaftyFlag) 
			print "Command to be executed - ", cmd_to_exe1
			res1 = runCmd(cmd_to_exe1)
			# Check that command executed successfully
			if (res1["STATUS"] == 0):
			    print "Output :\n", res1["OUTPUT"]
			else:
			    # Check for error or timeout in case of error
			    Dev_lst.append(dev)
			    DevErr_dict[dev]=res1["ERROR"]	
			    if (res1["ERROR"]):
				print "Error :\n", res1["ERROR"]
			    elif (res1["TIMEOUTERR"]):
				print "Timeout error occurred"
	fp.close()
else:
	print "ERROR:Invalid configuration file name passed.\n"
        print usage
        sys.exit(1)

if len(Dev_lst) != 0:  
	print "******************************************************************************"
	print 'ERROR:Firmware download failed on following device(s), Kindly refer respective logs for errors in detail.'
	for key in DevErr_dict:
		print "\nFirmware download failed on device \""+key+"\" due to below reasons, "+DevErr_dict[key]
else:
	print "*************************************************************"
	print '\nFirmware download on all devices passed successfully...!'
