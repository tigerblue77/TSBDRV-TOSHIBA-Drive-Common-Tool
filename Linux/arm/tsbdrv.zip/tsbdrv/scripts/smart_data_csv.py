#!/usr/bin/python
# -------------------------------------------------------------------------------
# Name:        smart_data_csv
#
# Purpose:     Query drive attributes and display CSV output
#
# Created:     26/11/2015
#
# Copyright:   Copyright (C) 2017-18 Toshiba Electronic Devices & Storage Corporation. All Rights Reserved.
#
# Licence:
#
# -------------------------------------------------------------------------------


# Import python modules
import sys
import subprocess
import csv
import re
import time
import threading
import os
import signal

helpstr = """
Query drive attributes and display CSV output
Script displays the required fields in CSV format
"""

usage = "usage: python %s <CsvFileName>\n%s" % (sys.argv[0], helpstr)
# Creating threading event
kil_chk = threading.Event()

# Check command line arguments, must be 2 including module name
if ((len(sys.argv) != 2) or (re.match(r'-h|--help',sys.argv[1]))):
    print usage
    sys.exit(1)
else:
    # check that command line argument contains csv extenstion file
    # if not create the file extension as csv
    csv_file1 = sys.argv[1]
    if csv_file1.endswith('.csv'):
        csv_file = csv_file1
    else:
        csv_file = csv_file1 + ".csv"

def cmd_exists(cmd):
    """This function is used to chek wheather the command is present on the system
       Input is the command
       Return True if present
       Return False if not present"""
    return any(
        os.access(os.path.join(path, cmd), os.X_OK)
        for path in os.environ["PATH"].split(os.pathsep)
    )
#check wheather  tsbdrv present on the system

if os.name == "nt":
    if cmd_exists("tsbdrv.exe"):
	   tsbdrvPath = "tsbdrv"
    else:
        #In windows check if parent directory contains the tsbdrv.exe
		path1 = os.getcwd()
		parentPath = os.path.abspath(os.path.join(path1, os.pardir))
		for root, dirs, files in os.walk(parentPath):
			for tsbdrvEXE in files:
				if re.search(r'tsbdrv.exe',tsbdrvEXE):
					tsbdrvPath = os.path.join(root,tsbdrvEXE)
					break
    #If in windows tsbdrv not found in the parent directory then we will exit
    try :
        tsbdrvPath
        print "tsbdrv is installed on the system"
    except NameError:
        print '''We are unable to find the tsbdrv on the system. Please add tsbdrv to the Environmental variables
                 or run the script from the TSBDRV_SCRIPT folder'''
        sys.exit(1)

else:
    #If system is linux we will exit script as tsbdrv is not found
    if cmd_exists("tsbdrv"):
	   tsbdrvPath = "tsbdrv"
    else:
        print "tsbdrv is not installed.Exiting the Script...."
        sys.exit(1)

# Open csv file binary write mode
file1 = open(csv_file, 'wb')
# use csv module writer method with quoting minimal
WRT = csv.writer(file1, quoting=csv.QUOTE_MINIMAL)
# Write first row of csv file, headers
WRT.writerow(["Date", "Model", "FW", "Serial", "POH", "END", "UWE",
              "URE", "UVE"])
WRT = csv.writer(file1, quoting=csv.QUOTE_MINIMAL)


def _kill_pid_after_timeout(pid):
    """Function to kill the process after set timeout
       Input : process id pid Return : None
    """

    os.kill(pid, signal.SIGTERM)
    # Kill the process with SIGTERM and inform to calling function
    kil_chk.set()
    return


def runCmd(cmd_to_exe):
    """Function to excute command
      Input : command to be executed
      Return : Dictionary of command ouput, error if any, status
               of execution, timeout error if occured
    """
    # Timeout set is 70 sec for execution of above command
    print "command - %s" % cmd_to_exe
    timeout = 70
    # Execute command using subprocess modul
    run_cmd = subprocess.Popen(cmd_to_exe, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, shell=True)
    # Get the pid of process
    pid = run_cmd.pid
    # start watchdog,if command taking longer time than timeout kill process
    watchdog = threading.Timer(timeout, _kill_pid_after_timeout, args=(pid, ))
    watchdog.start()
    # Get the command output and error in any from process
    (cmd_output, cmd_err) = run_cmd.communicate()
    status = run_cmd.wait()
    watchdog.cancel()
    timeout_err = kil_chk.isSet()
    kil_chk.clear()
    res = {"OUTPUT": cmd_output, "ERROR": cmd_err, "STATUS": status,
           "TIMEOUTERR": timeout_err}
    return res


def getDict(line):
    dict1 = {}
    #bb = line.split(":")
    cc = line.split(";")
    deviceId = ""
    for i in cc:
        matchObj1 = re.match(r"(\S+)=(\S+)", i)
        if matchObj1:
            params = matchObj1.groups()
            # if dict1.has_key(bb[0]):
            if re.search(r'physical_drive',params[0]):
				    dict1[params[1]] = {params[0]:params[1]}
				    deviceId = params[1]
            else:
			    tempArray = params[0].split("__")
			    dict1[deviceId][tempArray[2]] = params[1]
    return dict1

# def getDict1(line):
    # dict1 = {}
    # #bb = line.split(":")
    # cc = line.split(";")
    # deviceId = ""
    # for i in cc:
        # matchObj1 = re.match(r"(\S+)=(\S+)", i)
        # if matchObj1:
            # params = matchObj1.groups()
            # # if dict1.has_key(bb[0]):
            # if re.search(r'physical_drive',params[0]):
                                    # dict1[params[1]] = {params[0]:params[1]}
                                    # deviceId = params[1]
            # else:
                            # tempArray = params[0].split("__")
                            # dict1[deviceId][tempArray[2]] = params[1]
    # return dict1
def parseOutput(output):
    '''Function is used to parse the tsbdrv command output
       returns the dictionary formed as per the command output
    '''
    dict = {}
    outarray1 = output.rstrip().split(';')
    if 'See log file' in outarray1[-1]:
        outarray1.pop()
    for out in outarray1:
        if out:
            outarray2 = out.split('=')
            dict[outarray2[0]] = outarray2[1]
    return dict
def getDeviceType(deviceId):
    """
    Retrun the Device type for the particular device

    Input: Device e.g /dev/sda

    Retrun : String of device type e.g ATA,SCSI
    """
    deviceType=""
    cmd_query = "tsbdrv query %s -t" % (deviceId)
    Queryres = runCmd(cmd_query)
    checkOut(Queryres)
    Queryout = Queryres["OUTPUT"]
    QueryoutLines = Queryout.rstrip().split("\n")
    for line in QueryoutLines:
        deviceOut = line.rstrip().split(";")
        for devLine in deviceOut:
            deviceOutput = devLine.rstrip().split("=")
            if re.match(r'.*dev_type$',deviceOutput[0]):
                return deviceOutput[1]


def checkOut(reslocal):
    if (reslocal["STATUS"] == 0):
        print "Output :\n", reslocal["OUTPUT"]
        return "PASS"
    else:
        if (reslocal["ERROR"]):
            print "Error :\n", res1["ERROR"]
        elif (reslocal["TIMEOUTERR"]):
            print "Timeout error occured"
        return "FAIL"

cmd_to_exe1 = "\"%s\" query sas --terse"%(tsbdrvPath)
res1 = runCmd(cmd_to_exe1)
checkOut(res1)

smart_fields = ["Power-on Time",
                "SSD Percentage used Endurance Indicator",
                "Write Error:Total Uncorrected Errors",
                "Read Error:Total Uncorrected Errors",
                "Verify Error:Total Uncorrected Errors"]

for line1 in res1["OUTPUT"].split("\n"):

    mylist = []
    time1 = time.strftime("%m/%d/%y %H:%M")
    if re.match(r"\S+;\S+", line1):
        matchObj = re.match(r"(\S+);(\S+)", line1)
	dict2 = getDict(line1)
	device = dict2.keys()[0]
	for keys in ["firmware_version", "model_number", "serial_number"]:
		# if not dict2[device].has_key(keys):
		if keys in dict2.keys():
			dict2[device][keys] = ""
	cmd_to_exe2 = "\"%s\" smart info %s --terse -src all" %(tsbdrvPath,device)
	res2 = runCmd(cmd_to_exe2)
	chk_res = checkOut(res2)
	#print res2
	if (chk_res == "FAIL"):
		continue
        dict3 = {}
        dict4 = {}
	matchObj2 = re.match(r"(\S+);(\S+)", res2["OUTPUT"])
	if matchObj2:
            dict3 = parseOutput(res2["OUTPUT"])

        mylist.extend([time1, dict2[device]["model_number"],
			  dict2[device]["firmware_version"], dict2[device]["serial_number"]])
        #form the dictionary with the smart fileld
        for smartkeys in smart_fields:
            for smartoutkeys, smartoutvalues in dict3.items():
                if re.search(smartkeys,smartoutvalues):
                    dict4[smartkeys] = dict3[smartoutkeys.replace("field","value")]
                    if (smartkeys == "Power-on Time"):
                        dict4["Power-on Time"] = int (int (dict4["Power-on Time"])/60)
                    continue
        local_list = []
        for smrtkeys in smart_fields:
                # if not dict3[device1].has_key(smrtkeys):
                if smrtkeys not in dict4.keys():
                    local_list.append("")
                else:
                    local_list.append(dict4[smrtkeys])
	mylist.extend(local_list)

        # elif dict3[device1].has_key("power_on_hours"):
        WRT.writerow(mylist)
file1.close()
sys.exit(0)
